import fetch from 'node-fetch'

export class JiraClient {
  private baseUrl: string
  private email: string
  private apiToken: string

  constructor(baseUrl?: string, email?: string, apiToken?: string) {
    this.baseUrl = baseUrl || process.env.JIRA_BASE_URL || ''
    this.email = email || process.env.JIRA_EMAIL || ''
    this.apiToken = apiToken || process.env.JIRA_API_TOKEN || ''
  }

  private authHeader(): string {
    return `Basic ${Buffer.from(`${this.email}:${this.apiToken}`).toString('base64')}`
  }

  async fetchUserStory(issueKey: string): Promise<any> {
    if (!this.baseUrl || !this.email || !this.apiToken) {
      throw new Error('JIRA credentials (baseUrl, email, token) are required')
    }

    const endpoint = `${this.baseUrl.replace(/\/$/, '')}/rest/api/3/issue/${encodeURIComponent(issueKey)}`

    try {
      console.log(`Fetching user story from JIRA: ${endpoint}`)
      const response = await fetch(endpoint, {
        method: 'GET',
        headers: {
          'Authorization': this.authHeader(),
          'Accept': 'application/json',
        },
      })

      if (!response.ok) {
        const errorText = await response.text().catch(() => '')
        throw new Error(`JIRA API error: ${response.status} ${response.statusText} - ${errorText}`)
      }

      const data = await response.json()
      return data
    } catch (error) {
      console.error('Error fetching user story from JIRA:', error)
      throw error
    }
  }

  // validate credentials by calling /myself
  async fetchSelf(): Promise<any> {
    if (!this.baseUrl || !this.email || !this.apiToken) {
      throw new Error('JIRA credentials (baseUrl, email, token) are required')
    }
    const endpoint = `${this.baseUrl.replace(/\/$/, '')}/rest/api/3/myself`
    try {
      const response = await fetch(endpoint, {
        method: 'GET',
        headers: {
          'Authorization': this.authHeader(),
          'Accept': 'application/json'
        }
      })
      if (!response.ok) {
        const text = await response.text().catch(() => '')
        throw new Error(`JIRA validation error: ${response.status} ${response.statusText} - ${text}`)
      }
      return await response.json()
    } catch (error) {
      console.error('Error validating JIRA credentials:', error)
      throw error
    }
  }
}