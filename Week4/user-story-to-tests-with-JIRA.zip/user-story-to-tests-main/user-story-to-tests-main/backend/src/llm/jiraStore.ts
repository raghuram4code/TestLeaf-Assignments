import fs from 'fs'
import path from 'path'

type Creds = { baseUrl: string; email: string; token: string }

const CRED_PATH = path.join(__dirname, '../../.jira_creds.json')

export function saveCreds(creds: Creds) {
  try {
    fs.writeFileSync(CRED_PATH, JSON.stringify(creds), { encoding: 'utf8', mode: 0o600 })
    return true
  } catch (e) {
    console.error('Failed to save JIRA creds:', e)
    return false
  }
}

export function clearCreds() {
  try {
    if (fs.existsSync(CRED_PATH)) fs.unlinkSync(CRED_PATH)
    return true
  } catch (e) {
    console.error('Failed to clear JIRA creds:', e)
    return false
  }
}

export function getCreds(): Creds | null {
  try {
    if (!fs.existsSync(CRED_PATH)) return null
    const raw = fs.readFileSync(CRED_PATH, 'utf8')
    const parsed = JSON.parse(raw)
    if (parsed && parsed.baseUrl && parsed.email && parsed.token) return parsed as Creds
    return null
  } catch (e) {
    console.error('Failed to read JIRA creds:', e)
    return null
  }
}
