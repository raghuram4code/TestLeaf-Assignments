import express from 'express'
import { GroqClient } from '../llm/groqClient'
import { GenerateRequestSchema, GenerateResponseSchema, GenerateResponse } from '../schemas'
import { SYSTEM_PROMPT, buildPrompt } from '../prompt'
import { JiraClient } from '../llm/jiraClient'
import { saveCreds, clearCreds, getCreds } from '../llm/jiraStore'

export const generateRouter = express.Router()

generateRouter.post('/', async (req: express.Request, res: express.Response): Promise<void> => {
  try {
    // Validate request body
    const validationResult = GenerateRequestSchema.safeParse(req.body)
    
    if (!validationResult.success) {
      res.status(400).json({
        error: `Validation error: ${validationResult.error.message}`
      })
      return
    }

    const request = validationResult.data

    // Build prompts
    const userPrompt = buildPrompt(request)

    // Create GroqClient instance here to ensure env vars are loaded
    const groqClient = new GroqClient()

    // Generate tests using Groq
    try {
      const groqResponse = await groqClient.generateTests(SYSTEM_PROMPT, userPrompt)
      
      // Parse the JSON content
      let parsedResponse: GenerateResponse
      try {
        parsedResponse = JSON.parse(groqResponse.content)
      } catch (parseError) {
        res.status(502).json({
          error: 'LLM returned invalid JSON format'
        })
        return
      }

      // Validate the response schema
      const responseValidation = GenerateResponseSchema.safeParse(parsedResponse)
      if (!responseValidation.success) {
        res.status(502).json({
          error: 'LLM response does not match expected schema'
        })
        return
      }

      // Add token usage info if available
      const finalResponse = {
        ...responseValidation.data,
        model: groqResponse.model,
        promptTokens: groqResponse.promptTokens,
        completionTokens: groqResponse.completionTokens
      }

      res.json(finalResponse)
    } catch (llmError) {
      console.error('LLM error:', llmError)
      res.status(502).json({
        error: 'Failed to generate tests from LLM service'
      })
      return
    }
  } catch (error) {
    console.error('Error in generate route:', error)
    res.status(500).json({
      error: 'Internal server error'
    })
  }
})

// Fetch user story using per-request credentials (headers, query, or body) or fall back to env
generateRouter.get('/jira/:issueKey', async (req, res) => {
  const { issueKey } = req.params

  // prefer headers, then query params, then body, then server-stored creds, then env
  let baseUrl = (req.header('x-jira-baseurl') as string) || (req.query.baseUrl as string) || (req.body && req.body.baseUrl)
  let email = (req.header('x-jira-email') as string) || (req.query.email as string) || (req.body && req.body.email)
  let token = (req.header('x-jira-token') as string) || (req.query.token as string) || (req.body && req.body.token)

  if (!baseUrl || !email || !token) {
    const stored = getCreds()
    if (stored) {
      baseUrl = baseUrl || stored.baseUrl
      email = email || stored.email
      token = token || stored.token
    }
  }

  try {
    const jiraClient = new JiraClient(baseUrl, email, token)
    const userStory = await jiraClient.fetchUserStory(issueKey)
    res.json(userStory)
  } catch (error) {
    console.error('Error fetching user story:', error)
    const errorMessage = error instanceof Error ? error.message : 'Failed to fetch user story'
    res.status(500).json({ error: errorMessage })
  }
})

// Validate JIRA credentials (used by frontend connect button)
generateRouter.post('/jira/validate', async (req, res) => {
  const body = req.body || {}
  const baseUrl = (req.header('x-jira-baseurl') as string) || body.baseUrl || process.env.JIRA_BASE_URL
  const email = (req.header('x-jira-email') as string) || body.email || process.env.JIRA_EMAIL
  const token = (req.header('x-jira-token') as string) || body.token || process.env.JIRA_API_TOKEN

  try {
    const jiraClient = new JiraClient(baseUrl, email, token)
    const info = await jiraClient.fetchSelf()
    res.json({ ok: true, accountId: info.accountId || info.key || null })
  } catch (error) {
    console.error('JIRA validation error:', error)
    const message = error instanceof Error ? error.message : 'Validation failed'
    res.status(401).json({ ok: false, error: message })
  }
})

// Save server-side creds after validation
generateRouter.post('/jira/save', async (req, res) => {
  const { baseUrl, email, token } = req.body || {}

  if (!baseUrl || !email || !token) {
    return res.status(400).json({ ok: false, error: 'Missing baseUrl, email, or token' })
  }

  try {
    const jiraClient = new JiraClient(baseUrl, email, token)
    await jiraClient.fetchSelf()
    saveCreds({ baseUrl, email, token })
    res.json({ ok: true })
  } catch (error) {
    console.error('Error saving JIRA creds:', error)
    const errorMessage = error instanceof Error ? error.message : 'Failed to save credentials'
    res.status(500).json({ ok: false, error: errorMessage })
  }
})

// Clear server-side stored creds
generateRouter.delete('/jira/clear', async (req, res) => {
  try {
    clearCreds()
    res.json({ ok: true })
  } catch (error) {
    console.error('Error clearing JIRA creds:', error)
    const errorMessage = error instanceof Error ? error.message : 'Failed to clear credentials'
    res.status(500).json({ ok: false, error: errorMessage })
  }
})

// Check status (no token returned)
generateRouter.get('/jira/status', async (req, res) => {
  try {
    const stored = getCreds()
    if (!stored) return res.json({ ok: true, connected: false })
    res.json({ ok: true, connected: true, baseUrl: stored.baseUrl, email: stored.email })
  } catch (error) {
    console.error('Error reading JIRA creds:', error)
    const errorMessage = error instanceof Error ? error.message : 'Failed to read credentials'
    res.status(500).json({ ok: false, error: errorMessage })
  }
})