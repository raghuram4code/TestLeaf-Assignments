import { GenerateRequest, GenerateResponse } from './types'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/api'

export async function generateTests(request: GenerateRequest): Promise<GenerateResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/generate-tests`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request),
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
    }

    const data: GenerateResponse = await response.json()
    return data
  } catch (error) {
    console.error('Error generating tests:', error)
    throw error instanceof Error ? error : new Error('Unknown error occurred')
  }
}

export async function fetchUserStory(issueKey: string): Promise<any> {
  try {
    // Server-side stored credentials will be used by the backend. No tokens in localStorage.
    const response = await fetch(`${API_BASE_URL}/generate-tests/jira/${encodeURIComponent(issueKey)}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return data
  } catch (error) {
    console.error('Error fetching user story:', error)
    throw error instanceof Error ? error : new Error('Unknown error occurred')
  }
}

export async function connectJira(baseUrl: string, email: string, token: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(`${API_BASE_URL}/generate-tests/jira/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ baseUrl, email, token })
    })

    const data = await res.json().catch(() => ({}))
    if (!res.ok) return { ok: false, error: data.error || 'Validation failed' }
    return { ok: true }
  } catch (err) {
    console.error('connectJira error:', err)
    return { ok: false, error: err instanceof Error ? err.message : 'Unknown error' }
  }
}

export async function saveJiraCreds(baseUrl: string, email: string, token: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(`${API_BASE_URL}/generate-tests/jira/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ baseUrl, email, token })
    })
    const data = await res.json().catch(() => ({}))
    if (!res.ok) return { ok: false, error: data.error || 'Failed to save credentials' }
    return { ok: true }
  } catch (err) {
    console.error('saveJiraCreds error:', err)
    return { ok: false, error: err instanceof Error ? err.message : 'Unknown error' }
  }
}

export async function clearJiraCreds(): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(`${API_BASE_URL}/generate-tests/jira/clear`, { method: 'DELETE' })
    const data = await res.json().catch(() => ({}))
    if (!res.ok) return { ok: false, error: data.error || 'Failed to clear credentials' }
    return { ok: true }
  } catch (err) {
    console.error('clearJiraCreds error:', err)
    return { ok: false, error: err instanceof Error ? err.message : 'Unknown error' }
  }
}

export async function getJiraStatus(): Promise<{ ok: boolean; connected: boolean; baseUrl?: string; email?: string; error?: string }> {
  try {
    const res = await fetch(`${API_BASE_URL}/generate-tests/jira/status`)
    const data = await res.json().catch(() => ({}))
    if (!res.ok) return { ok: false, connected: false, error: data.error || 'Failed to get status' }
    return { ok: true, connected: !!data.connected, baseUrl: data.baseUrl, email: data.email }
  } catch (err) {
    console.error('getJiraStatus error:', err)
    return { ok: false, connected: false, error: err instanceof Error ? err.message : 'Unknown error' }
  }
}